﻿namespace P01._Library
{
    using System;

    public class IteratorsAndComparators
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
